@extends('layouts.general-layout.app_base')

@section('lateral_menu')
	@include('layouts.su-layouts.lateral_menu')
@endsection

@section('top_bar')
	@include('layouts.su-layouts.top_bar')
@endsection