@extends('layouts.general-layout.app_base')

@section('lateral_menu')
	@include('layouts.ad-layouts.lateral_menu')
@endsection

@section('top_bar')
	@include('layouts.ad-layouts.top_bar')
@endsection