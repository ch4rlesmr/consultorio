<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AllergyPatient extends Model
{
    //
}
