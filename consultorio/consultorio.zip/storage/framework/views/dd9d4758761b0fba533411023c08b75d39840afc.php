<?php $__env->startSection('lateral_menu'); ?>
	<?php echo $__env->make('layouts.su-layouts.lateral_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top_bar'); ?>
	<?php echo $__env->make('layouts.su-layouts.top_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general-layout.app_base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>