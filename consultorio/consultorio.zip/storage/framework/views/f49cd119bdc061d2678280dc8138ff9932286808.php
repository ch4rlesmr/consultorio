<?php $__env->startSection('content'); ?>
<div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3><?php echo e($message); ?> <!-- <small>Click to add/edit events</small> --></h3>
              </div>

              <!-- <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div> -->
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_content">
                    <?php if( isset( $product ) ): ?>
                        <?php echo e(Form::open( array( 'action' => array('ProductController@update', $product->id), 'method' => 'PUT', 'class' => 'form-horizontal form-label-left inventory', 'novalidate' => 'novalidate' ) )); ?>

                    <?php else: ?>
                          <?php echo e(Form::open( array( 'action' => 'ProductController@store', 'method' => 'POST', 'class' => 'form-horizontal form-label-left inventory', 'novalidate' => 'novalidate' ) )); ?>

                    <?php endif; ?>
                          
                          <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                              <div class="x_panel">
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group item">
                                  <small class="info-field">Referencia</small>
                                  <input data-validate-length-range="2" data-validate-words="1" type="text" class="form-control has-feedback-left" placeholder="Serial" name="reference-inventory" id="reference-inventory" value="<?php echo e(isset( $product ) ? $product->reference : ''); ?>" required>
                                  <span class="fa fa-file-text form-control-feedback form-control-feedback-input left" aria-hidden="true"></span>
                                </div>

                                <div class="col-md-6 col-sm-6 col-xs-12 form-group item">
                                  <small class="info-field">Nombre Inventario</small>
                                  <input data-validate-length-range="2" data-validate-words="1" type="text" class="form-control has-feedback-left" placeholder="Inventario" name="name-inventory" id="name-inventory" value="<?php echo e(isset( $product ) ? $product->name : ''); ?>" required>
                                  <span class="fa fa-file-text form-control-feedback form-control-feedback-input left" aria-hidden="true"></span>
                                </div>

                                <div class="col-md-4 col-sm-6 col-xs-12 form-group item">
                                  <small class="info-field">Garantia</small>
                                  <input type="text" class="form-control has-feedback-left" placeholder="Inventario" name="warranty-inventory" id="warranty-inventory" value="<?php echo e(isset( $product ) ? $product->warranty : ''); ?>">
                                  <span class="fa fa-file-text form-control-feedback form-control-feedback-input left" aria-hidden="true"></span>
                                </div>

                                <div  class="col-md-4 col-sm-2 col-xs-12 form-group item">
                                  <small class="info-field has-feedback-left">Tipo Inventario</small>
                                  <select class="select2_single form-control has-feedback-left" tabindex="0" name="inventory-type" id="inventory-type" required>
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productType): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                      <option value="<?php echo e($productType->id); ?>"
                                        <?php if( isset($product) ): ?>
                                          <?php if( $productType->id === $product->product_id ): ?>
                                            <?php echo e('selected'); ?>

                                          <?php endif; ?>
                                        <?php endif; ?>
                                        ><?php echo e($productType->name_type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                  </select>
                                  <span class="fa fa-list-alt form-control-feedback form-control-feedback-input left" aria-hidden="true"></span>
                                </div>

                                <div  class="col-md-4 col-sm-2 col-xs-12 form-group item">
                                  <small class="info-field has-feedback-left">Estado del Elemento</small>
                                  <select class="select2_single form-control has-feedback-left" tabindex="0" name="status-inventory" id="status-inventory" required>
                                    <option value="E" <?php if( isset($product) ): ?>  <?php if( $product->status === 'E' ): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>Excelente</option>
                                    <option value="B" <?php if( isset($product) ): ?> <?php if( $product->status === 'B' ): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>Bueno</option>
                                    <option value="R" <?php if( isset($product) ): ?> <?php if( $product->status === 'R' ): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>Regular</option>
                                    <option value="M" <?php if( isset($product) ): ?> <?php if( $product->status === 'M' ): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>Mal</option>
                                    <option value="P" <?php if( isset($product) ): ?> <?php if( $product->status === 'P' ): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>Pesimo</option>
                                  </select>
                                  <span class="fa fa-list-alt form-control-feedback form-control-feedback-input left" aria-hidden="true"></span>
                                </div>

                                <div class="col-md-4 col-sm-6 col-xs-12 form-group item">
                                  <small class="info-field">Cantidad</small>
                                  <input type="text" class="form-control has-feedback-left num_input" placeholder="Cantidad" name="quantity-inventory" id="quantity-inventory" value="<?php echo e(isset( $product ) ? $product->quantity : 1); ?>">
                                  <span class="fa fa-file-text form-control-feedback form-control-feedback-input left" aria-hidden="true"></span>
                                </div>

                                <div class="col-md-4 col-sm-6 col-xs-12 form-group item">
                                  <small class="info-field">Marca</small>
                                  <input type="text" class="form-control has-feedback-left" placeholder="Marca" name="trademark-inventory" id="trademark-inventory" value="<?php echo e(isset( $product ) ? $product->trademark : ''); ?>">
                                  <span class="fa fa-file-text form-control-feedback form-control-feedback-input left" aria-hidden="true"></span>
                                </div>

                                <div  class="col-md-4 col-sm-2 col-xs-12 form-group item">
                                  <small class="info-field has-feedback-left">Presentación</small>
                                  <select class="select2_single form-control has-feedback-left" tabindex="0" name="presentation-inventory" id="presentation-inventory" required>
                                    <option value="U" <?php if( isset($product) ): ?>  <?php if( $product->presentation === 'U' ): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>Unidad</option>
                                    <option value="P" <?php if( isset($product) ): ?> <?php if( $product->presentation === 'P' ): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>Paquete</option>
                                  </select>
                                  <span class="fa fa-list-alt form-control-feedback form-control-feedback-input left" aria-hidden="true"></span>
                                </div>

                                <div class="col-md-12 col-sm-6 col-xs-12 form-group item">
                                  <small class="info-field">Observación del Elemento de inventario </small>
                                  <textarea class="form-control" rows="5" placeholder="Observación" name="description-inventory"><?php echo e(isset( $product ) ? $product->observation : ''); ?></textarea>
                                </div>

                                <div class="form-group pull-right">
                                  <button type="submit" class="btn btn-success"><i class="fa fa-save"></i>&nbsp; &nbsp; <strong>Guardar Elemento</strong></button>
                                </div>

                              </div>
                            </div>
                          </div>
                        <?php echo e(Form::close()); ?>

                     
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.su_main_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>